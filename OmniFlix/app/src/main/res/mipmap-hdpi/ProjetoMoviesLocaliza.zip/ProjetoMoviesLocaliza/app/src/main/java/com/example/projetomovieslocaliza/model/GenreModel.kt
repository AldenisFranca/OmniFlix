package com.example.projetomovieslocaliza.model

data class GenreModel( val name: String){
    override fun toString(): String {
        return name
    }
}
