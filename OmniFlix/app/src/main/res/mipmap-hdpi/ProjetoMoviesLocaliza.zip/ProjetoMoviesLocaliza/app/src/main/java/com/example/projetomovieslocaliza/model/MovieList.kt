package com.example.projetomovieslocaliza.model

class MovieList(val page: Int, val results: List<MovieModel>)