package com.example.projetomovieslocaliza

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        println(ehUmBomFilme("brazil"))
        criarNumeros()

    }
    fun ehUmBomFilme(filme: String?): String {
        return when {
            filme.isNullOrBlank() -> "Erro, preciso de um nome pra avaliar"
            filme.length < 5 -> "Um nome tão curto não pode ser bom"
            else -> "É, talvez seja bom"

        }
    }

    fun criarNumeros() {
        val lista1 = List(10) { it + 1 }
        var mutableList = mutableListOf<String>()
        lista1.forEach {
            mutableList.add(if (it % 2 == 0) it.toString() else "-")
        }
        println(mutableList)
    }

}