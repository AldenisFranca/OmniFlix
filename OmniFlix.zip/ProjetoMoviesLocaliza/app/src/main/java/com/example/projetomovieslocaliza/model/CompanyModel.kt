package com.example.projetomovieslocaliza.model

data class CompanyModel(val name: String) {
    override fun toString(): String {
        return name
    }
}
