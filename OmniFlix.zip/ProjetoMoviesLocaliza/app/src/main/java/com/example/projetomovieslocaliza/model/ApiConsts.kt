package com.example.projetomovieslocaliza.model

object ApiConsts {
    const val API_KEY = "3d1b4cc572f9a3c4563fefe9ee925770"
}